<?php
	session_start();
	include("dbconnect.php");
	$_SESSION["api_token"] = "edureka321";
	$_SESSION["uniquekey"] = "";
	$_SESSION["username"] = "";
	$_SESSION["logactivity"]="";
	$_SESSION["attempt"] = 0;
	$_SESSION["userasadmin"] = "";
	//$hostname = gethostname();
	$hostname = getenv("MYHOST");
	$username = getenv("username");
	if (empty($username)) {
		$username = posix_getpwuid(posix_geteuid())['name'];
	}
	if (empty($username)) {
		$username = get_current_user();
	}
	//$username = posix_getpwuid(posix_geteuid());
	//$username = get_current_user();
	$servername = $_SERVER['SERVER_NAME'];
	//$password = $_POST['password'];
	$data = array(
		'hostname' => $hostname,
		'username' => $username,
		'servername' => $servername,
		'token' => "edureka321"
	);
	$conn = connectdb();
	curl_login($data);
	$_SESSION["username"] = $username;
	$data1 = array(
		'username' => $_SESSION["username"],
		'token' => "edureka321"
	);
	$attemptstatus = curl_attemptstatus($data1);
	
	if ((isset($_SESSION["uniquekey"]) && !empty($_SESSION["uniquekey"])) && (isset($_SESSION["username"]) && !empty($_SESSION["username"])))
	{
?>
		<html>
			<head>
				<title>Hack Me  - MY SHOP</title>
				<link rel="icon" href="favicon.ico" type="image/x-icon" />
				<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
				<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
				<link href="//db.onlinewebfonts.com/c/facc2325c1dff1377bb6bf9f0fb965f6?family=Museo+Slab" rel="stylesheet" type="text/css"/>
				<link rel="stylesheet" href="assets/css/edureka_zeplin.css">
				<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
				<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
				<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
				<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
				
			</head>
			<body>
				<header class="header-section" style="text-align: center;background-color: #007bff;background-image: linear-gradient(to left,#248de4,#0c5397);position:fixed;z-index: 3;width: 100%">
					<nav class="navbar navbar-expand-lg" style="position:relative">
						<br/>
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-6">
									<div class="row">
										<!--<img src="<?php echo "product_images/edureka!.png"; ?>" class="img-responsive m-auto d-block" style="align: left" /> -->
										<!-- <img src="https://d1jnx9ba8s6j9r.cloudfront.net/community/qa-theme/Donut-theme/images/edureka!.png" alt="edu-community" > -->
										<i class="edureka">edureka!</i>
										<i class="Hack-Me">Hack Me</i>
									</div>
								</div>
								<div class="col-md-1"></div>
								<div class="col-xs-12 col-md-5">
									<form class="examples" id="searchForm" >
										<input type="text" name="searchItem" onkeyup="myFunction()" id="searchItem" class="Rectangle-4-Copy-4" placeholder="Search here.." autocomplete="off" size="50">
										<button type="submit" class="Rectangle-4-Copy-5"><i class="fa fa-search Shape"></i></button>
										<!-- <button type="submit" onclick="search(document.getElementById('searchbar').value)"><i class="fa fa-search"></i></button> -->
										<!-- <?php echo(strftime("%d.%m.%Y %H:%M")); ?></p> -->
									</form>
								</div>
							</div>
						</div>
					</nav>
				</header>
				<br>
				<br>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12"><br/><br/><br></div>
					</div>
					<div class="row">
						<?php
							$conn = connectdb();
							$sql = "select * from problemtable order by problemid ASC";
							$result = $conn->query($sql);							
							if ($result->num_rows > 0) {
								while($row = $result->fetch_assoc())
								{
						?>
						<div class="col-md-4">
							<form method="<?php echo $row["problemmethod"]; ?>" action="<?php echo $row["problemlink"]; ?>" class="m-auto">
								<a href="<?php echo $row["problemlink"]; ?>" style="text-decoration: none;">
									<div class="Rectangle-Copy-12">
										<!--<div style="width: 400px;height: 107px;border-radius: 4px;background-image: linear-gradient(75deg, #09adef, #bdd377 100%);"> -->
										<div style="width: 400px;height: 107px;border-radius: 4px;background-image: linear-gradient(75deg, <?php echo $image_code[$row['problemid']][0]; ?>, <?php echo $image_code[$row['problemid']][1];?> 100%);"> 
											<!-- <img src="<?php echo "product_images/".$row["problemimage"]; ?>" class="img-responsive m-auto d-block" width="100%" height="150" /><br /> -->
										</div>
										<br>
										<div style="text-align: center; height: 60px;">
											<h5 class="SQL-Injection-Search"><?php echo $row["problemid"].".  ".$row["problemtitle"] ?></h5>
										</div>
										<h6 class="Last-Attempt-Date-an"><?php echo "Last Attempt Date and Status<br>";?></h6>
										<div style="height: 65px;">
											<h6 class="Friday-20-Mar-2020"><?php if (isset($attemptstatus[$row["problemid"]]["attemptdate"])) {echo $attemptstatus[$row["problemid"]]["attemptdate"];} ?></h6>
											<h6 class="Wrong-Answer"><?php if (isset($attemptstatus[$row["problemid"]]["attemptstatus"])) {if($attemptstatus[$row["problemid"]]["attemptstatus"] == "correct answer") {echo "<font color=green><img src=https://cdn1.iconfinder.com/data/icons/warnings-and-dangers/400/Warning-02-512.png class=Path-4> Correct Answer</font>";}else {echo "<font color=red><img src=https://previews.123rf.com/images/juliarstudio/juliarstudio1604/juliarstudio160400949/55074496-red-cross-check-mark-icon-in-simple-style-on-a-white-background.jpg class=Path-4> Wrong Answer</font>";}} else {echo "NOT ATTEMPTED";} ?></h6>
										</div>
										<div>
											<input type="submit" name="start" class="Start" value="Start" />
										</div>
										<br/>
									</div>
								</a>
							</form>
						</div>
						
						<?php
									
								}
							}
							$conn->close();
						?>
					</div>
				</div>
				<br />
				<script>
					/*function search(string){
					window.find(string);
					}*/
					/*function search() {
					 
					   var name = document.getElementById("searchForm").elements["searchItem"].value;
					   var pattern = name.toLowerCase();
					   var targetId = "";
					 
					   var divs = document.getElementsByClassName("col-md-4");
					   for (var i = 0; i < divs.length; i++) {
						  var para = divs[i].getElementsByTagName("h5");
						  var index = para[0].innerText.toLowerCase().indexOf(pattern);
						  if (index != -1) {
							 targetId = divs[i].parentNode.id;
							 document.getElementById(targetId).scrollIntoView();
							 break;
						  }
					   }  
					}*/
					function myFunction() {
					  var input = document.getElementById("searchItem");
					  var filter = input.value.toLowerCase();
					  //var nodes = document.getElementsByClassName('Rectangle-Copy-12');
					  //var nodes = document.getElementById("searchblock");
					  //var nodes = document.getElementsByClassName('m-auto');
					  var nodes = document.getElementsByClassName('col-md-4');
					  /*var innernode [];
					  var j=0;*/

					  for (i = 0; i < nodes.length; i++) {
						if (nodes[i].innerText.toLowerCase().includes(filter)) {
						  nodes[i].style.display = "block";
						} else {
						  nodes[i].style.display = "none";
						}
					  }
					  /*for (k = 0; k < innernode.length; k++) {
						  innernode[k].style.display = "block";
						  
					  }*/
					}
				</script>
			</body>
		</html>
<?php
	}
?>
