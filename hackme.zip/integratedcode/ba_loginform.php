<?php
	session_start();
	include("dbconnect.php");
	if(!isset($_SESSION['uniquekey']) && empty($_SESSION['uniquekey']) && !isset($_SESSION["username"]) ) {
	   header("Location: ./index.php"); 
		die();
	}
	$problemid = "";
	$problemtitle = "";
	$problemdescription = "";
	

// create connection
	$conn = connectdb();

	$sql = "select * from problemtable where problemid=18";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$problemid = $row["problemid"];
			$problemtitle = $row["problemtitle"];
			$problemdescription = $row["problemdescription"];    
		}
	}
	$conn->close();	
?>
<html>
	<head>
		<title>Hack Me - Broken Authenntication Login Forms</title>
		<script src="assets/js/jquery-1.11.1.min.js"></script>
		
		<script src="assets/js/bootstrap.min.js"></script>
		
		<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		
		<script src="assets/js/echo.min.js"></script>
		<script src="assets/js/jquery.easing-1.3.min.js"></script>
		<script src="assets/js/bootstrap-slider.min.js"></script>
	    <script src="assets/js/jquery.rateit.min.js"></script>
	    <script type="text/javascript" src="assets/js/lightbox.min.js"></script>
	    <script src="assets/js/bootstrap-select.min.js"></script>




	    <script src="assets/js/wow.min.js"></script>
		<script src="assets/js/scripts.js"></script>


		
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<meta name="description" content="">
		<meta name="author" content="">
	    <meta name="keywords" content="MediaCenter, Template, eCommerce">
	    <meta name="robots" content="all">
		
		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
		<link href="//db.onlinewebfonts.com/c/facc2325c1dff1377bb6bf9f0fb965f6?family=Museo+Slab" rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="assets/css/edureka_zeplin.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script type="text/javascript" src="./js/links.js"></script>

		
		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">
		<style>
			
		</style>
	</head>

	<body>
		<script>
			function myFunc() {
			  var x = document.getElementById("userpwd");
			  if (x.type === "password") {
				x.type = "text";
			  } else {
				x.type = "password";
			  }
			}
		</script>
		<header class="header-section" style="text-align: center;background-color: #007bff;background-image: linear-gradient(to left,#248de4,#0c5397);position:fixed;z-index: 3;width: 100%">
			<nav class="navbar navbar-expand-lg" style="position:relative">
				<br/>
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-5">
							<div class="row">
								<!--<img src="<?php echo "product_images/edureka!.png"; ?>" class="img-responsive m-auto d-block" style="align: left" /> -->
								<!-- <img src="https://d1jnx9ba8s6j9r.cloudfront.net/community/qa-theme/Donut-theme/images/edureka!.png" alt="edu-community" > -->
								<i class="edureka">edureka!</i>
								<i class="Hack-Me">Hack Me</i>
							</div>
						</div>
						<div class="col-md-2"></div>
					</div>
				</div>
			</nav>
		</header>
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-3" style="background-color: #fbfbfb;border-right: solid 1px #dfdfdf;">
					<div class="row">
						<nav>
							<div class="nav-wrapper">
								<br><br><br>
								<div class="col s12">
									<a href="./" class="breadcrumb-item" style="color: #000000;display: inline-block;padding-left: 10px;font-family: Open Sans;font-weight: bold;text-decoration: none;"><i class="icon fa fa-home"></i>HOME</a>
									<a href="#!" class="breadcrumb-item" style="color: #a4a4a4;display: inline-block;font-family: Open Sans;text-decoration: none;"> BA LOGIN FORMS</a>
								</div>
							</div>
						</nav>
					</div>
					<div class="row">
						<div class="col-md-12">
							<h3 class="Problemname"><?php echo $problemtitle."</br>"; ?></h3>
							<h3 class="Question">Question</h3>
							<p class="Problemdes"><?php echo $problemdescription; ?></p>
						</div>
					</div>
					<br><br>
					<div class="row">
						<div class="col-md-12">
							<h3 class="Answer">Answer</h3>
							<p class="Answer-des">Enter username and password separated by =(eg abc=def without any space. mind the letter case)</p>
							<form method="post" class="answer_box">
								<textarea placeholder="Enter Your Answer Here" name="answer" id="answer" size="40" autocomplete="off" required class="Answer_area" /></textarea>
								<br><br>
								<input type="submit" class="Submit_Answer" value="Submit">
							</form>
							<?php
								if(isset($_POST['answer']))
								{
									$answer = $_POST['answer'];
									$data = array(
										'problemid' => $problemid,
										'username' => $_SESSION["username"],
										'answer' => $answer,
										'log' => $_SESSION["logactivity"],
										'sessionid' => $_SESSION['uniquekey'],
										'date' => date("Y-m-d")
									);
									curl_answer($data);
								}
							?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<br><br><br><br>
						</div>
					</div>
				</div>
		
		
				<div class="col-md-9" style="background-color: #f1f1f1;">
					<div class="row">
						<br><br>
					</div>
					<br><br><br>
					<br><br><br>					
					<div class="row">
						<div class="col-md-3"></div>
						<div class="col-md-6 col-sm-6">
							<div class="Rectangle-signin">
								<br>
								<h4 class="Sign-In">Sign In</h4>
								<p class="Login-please">Hello, please login to your account.</p>
								<br>
								<form  method="post" onsubmit="return TryToLogin()" class="loginforms">
									<div class="row">
										<label class="Username-signin" >Username</label>
										<input type="text" class="Rectangle-username-signin" name="userlogin" id="userlogin" autocomplete="off" placeholder="Enter Username" required />
									</div>
									<div class="row">
										<div class="col-md-12">
											<br>
										</div>
									</div>
									<div class="row">						 										
										<label class="Username-signin" >Password</label><br/>
										<input type="password" class="Rectangle-username-signin" name="userpwd" id="userpwd" autocomplete="off" placeholder="Enter Password" required /><span onclick="myFunc()" class="fa fa-fw fa-eye Show-password toggle-password"></span>
										<!-- <input type="checkbox" onclick="myFunction()"> Show Password <i class="fa fa-eye"></i> -->
									</div>
									<div class="row">
										<div class="col-md-12">
											<br>
										</div>
									</div>
									<div class="row">
										<button type="submit" class="Rectangle-signin-login" name="login">Login</button>
									</div>
									<div style="display: none;">
										<font color="white">Username:<?php echo $what_name; ?></font>
										<font color="white">Password:<?php echo $what_value; ?></font>
									</div>
								</form>
							</div>
						</div>			
					</div>
					
					<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-8">
							<br>
							<?php
								if(isset($_POST['userlogin']) && isset($_POST['userpwd']))
								{
									$username = sanitize_string($_POST['userlogin']);
									$userpwd = sanitize_string($_POST['userpwd']);
									if (($username == $what_name) && ($userpwd == $what_value))
									{
										$objectiveresult = "Successful login";
										echo "<font color=green style=\" font-family: Open Sans; font-weight: bold;\">welcome champ( ".$username." ) Login successful</font> ";
									}
									else
									{
										 echo "<font color=red style=\" font-family: Open Sans; font-weight: bold;\">Invalid username or password</font>";
										 $objectiveresult = "Invalid username or password";
									}
									
									$data = array(
									'sessionid' => $_SESSION['uniquekey'],
									'date' => date("Y-m-d"),
									'problemid' => $problemid,
									'problemname' => 'ba_loginforms',
									'problemstatus' => $objectiveresult
									);
									curl_logactivity($data);
									$_SESSION["logactivity"] = $_SESSION['uniquekey']." ".date("Y-m-d")." ".$objectiveresult." "."ba_loginforms";
								}
							?>
							
						</div>
						<div class="col-md-3"></div>
					</div>
				</div>
			</div>
		</div>
	</body>

</html>