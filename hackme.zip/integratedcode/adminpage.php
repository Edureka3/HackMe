<?php
	session_start();
	include("dbconnect.php");
	if(!isset($_SESSION['uniquekey']) && empty($_SESSION['uniquekey']) && !isset($_SESSION["username"]) ) {
	   header("Location: ./index.php"); 
		die();
	}

?>
<html>
	<head>
		<title>Hack Me - ADMIN PAGE</title>
		<script src="assets/js/jquery-1.11.1.min.js"></script>
		
		<script src="assets/js/bootstrap.min.js"></script>
		
		<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		
		<script src="assets/js/echo.min.js"></script>
		<script src="assets/js/jquery.easing-1.3.min.js"></script>
		<script src="assets/js/bootstrap-slider.min.js"></script>
	    <script src="assets/js/jquery.rateit.min.js"></script>
	    <script type="text/javascript" src="assets/js/lightbox.min.js"></script>
	    <script src="assets/js/bootstrap-select.min.js"></script>




	    <script src="assets/js/wow.min.js"></script>
		<script src="assets/js/scripts.js"></script>


		
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<meta name="description" content="">
		<meta name="author" content="">
	    <meta name="keywords" content="MediaCenter, Template, eCommerce">
	    <meta name="robots" content="all">
		
		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
		<link href="//db.onlinewebfonts.com/c/facc2325c1dff1377bb6bf9f0fb965f6?family=Museo+Slab" rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="assets/css/edureka_zeplin.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script type="text/javascript" src="./js/adm.js"></script>
		<script type="text/javascript" src="./js/links.js"></script>

		
		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">
		<style>
			
		</style>
	</head>

	<body>
		<header class="header-section" style="text-align: center;background-color: #007bff;background-image: linear-gradient(to left,#248de4,#0c5397);position:fixed;z-index: 3;width: 100%">
			<nav class="navbar navbar-expand-lg" style="position:relative">
				<br/>
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-5">
							<div class="row">
								<!--<img src="<?php echo "product_images/edureka!.png"; ?>" class="img-responsive m-auto d-block" style="align: left" /> -->
								<!-- <img src="https://d1jnx9ba8s6j9r.cloudfront.net/community/qa-theme/Donut-theme/images/edureka!.png" alt="edu-community" > -->
								<i class="edureka">edureka!</i>
								<i class="Hack-Me">Hack Me</i>
							</div>
						</div>
						<div class="col-md-2"></div>
					</div>
				</div>
			</nav>
		</header>
		
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8 body-content cnt-home">
					<br><br>
					<div class="row top-bar">
						<div class="container">
							<div class="header-top-inner">
								<div class="cnt-account">
									<ul class="list-unstyled list-inline">
										<a><i class="icon fa fa-edit"></i>Feedback</a>
										<a><i class="icon fa fa-rocket"><span class="key"> Track records</i></a>
										<a class="icon fa fa-line-chart"><span class="key"> Usage Graph</b></a>
										<a class="icon fa fa-ticket"><span class="key"> Create ticket</b></a>
										<a class="icon fa fa-comments"><span class="key"> Message</b></a>
										<a><i class="icon fa fa-user" style="color:red"></i> Admin Page</a>
										<a href="smngmnt_admin.php"><i class="icon fa fa-sign-in"></i>Logout</a>
										<font color="green"><h3>Welcome <?php echo $_SESSION["userasadmin"]; ?></h3></font>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<br><br><br>
					<br><br><br>
					<div class="row sign-in-page">
						<div class="col-md-2"></div>
						<div class="col-md-8 col-sm-8 sign-in">
							<h4 style="text-align:center;">WELCOME BACK ADMIN</h4>
							<p style="text-align:center;">Check your messages and tickets above and make plan accordingly </p>
						</div>			
					</div>
					<br><br>
					<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-8">
							<?php
							?>
						</div>
						<div class="col-md-3"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e1.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e2.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e3.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e7.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e8.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<form method="post">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:2px;">
							<center><img src="<?php echo "product_images/e9.jpg";?>" alt="centered image" width="300" /></center>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>