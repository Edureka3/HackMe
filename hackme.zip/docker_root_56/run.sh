
export MYHOST=$(uname -n)
docker-compose up -d
